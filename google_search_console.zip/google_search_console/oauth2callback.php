<?php
require_once __DIR__.'/google-api-php-client/vendor/autoload.php';

session_start();

$client = new Google_Client();
$credentials_file = __DIR__.'/client_id.json';
$client->setAuthConfig($credentials_file);
$client->setRedirectUri('http://' . $_SERVER['HTTP_HOST'] . '/wp-content/plugins/google_search_console/oauth2callback.php');
$scope = 'https://www.googleapis.com/auth/webmasters.readonly';
$client->addScope($scope);

if (! isset($_GET['code'])) {
  $auth_url = $client->createAuthUrl();
  header('Location: ' . filter_var($auth_url, FILTER_SANITIZE_URL));
} else {
  //$token = $client->authenticate($_GET['code']);
  $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
  $_SESSION['access_token'] = $token;
  $redirect_uri = 'http://' . $_SERVER['HTTP_HOST'] .'/wp-admin/?page=mymenu';
  header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
}
