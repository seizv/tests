<?php
/*
Plugin Name: google-search-console
Plugin URI:
Description: authentication for google search console
Version: 1.0
Author: Vitalii Seiz
Author URI: http://seizv.github.io
License: GPL2
*/

add_action( 'admin_menu', 'register_my_menu_page' );
function register_my_menu_page(){
    add_menu_page(
        'Google Search Console', 'Seacrh Console', 'manage_options', 'mymenu', 'my_menu_page', plugins_url('google_search_console/images/icon.png' ), 6
    );
}

function my_menu_page() {
    require_once __DIR__.'/google-api-php-client/vendor/autoload.php';

    session_start();

    $client = new Google_Client();
    $credentials_file = __DIR__.'/client_id.json';
    $client->setAuthConfig($credentials_file);
    $scope = 'https://www.googleapis.com/auth/webmasters.readonly';
    $client->addScope($scope);

    if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
      $client->setAccessToken($_SESSION['access_token']);
      //тут должен быть запрос и ответ от api
      //$search_service = new Google_Service_Resource($client);
      //$info = $seacrh->call("https://www.googleapis.com/webmasters/v3/sites");
      //echo json_encode($info);
    } else {
      $redirect_uri = plugins_url().'/google_search_console/oauth2callback.php';
      header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
    }
}
